# K I B I R A — Phase 1 site

This is a lightweight, static public website. Open `index.html` in any modern browser to preview it locally.

## Before publishing

1. Replace the CSS art and photography placeholders with original assets from `../assets/photography/` and `../assets/digital-art/`.
2. Confirm and replace the placeholder email address in `index.html`.
3. Add the preferred booking flow, service details, social links, and location when supplied.

No passwords, API credentials, or social account secrets belong in this project.
